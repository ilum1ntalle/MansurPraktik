import csv
import os
import uuid
from datetime import datetime, date
import tkinter as tk
from tkinter import ttk, messagebox

APP_TITLE = "Запись на приём к врачу"
CSV_FILE = "appointments.csv"
MAX_COMPLAINTS = 300

DOCTORS = {
    "Терапевт": ["Иванова Анна Сергеевна", "Садыков Марат Ерланович"],
    "Кардиолог": ["Петрова Елена Викторовна", "Ахметов Данияр Болатович"],
    "Невролог": ["Смирнова Ольга Андреевна", "Ким Артём Сергеевич"],
    "Дерматолог": ["Касымова Айгуль Нурлановна", "Орлов Максим Игоревич"],
    "Офтальмолог": ["Васильев Павел Олегович", "Нуртаева Динара Аскаровна"],
}

TIMES = [f"{hour:02d}:{minute:02d}" for hour in range(9, 17) for minute in (0, 30)]
TIMES += ["17:00"]
STATUSES = ["Запланирован", "Пациент принят", "Отменён", "Пациент не явился"]
CSV_FIELDS = [
    "id", "last_name", "first_name", "middle_name", "iin", "birth_date",
    "phone", "email", "specialty", "doctor", "appointment_date",
    "appointment_time", "visit_type", "format", "complaints", "status"
]


class AppointmentApp:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_TITLE)
        self.root.geometry("1450x850")
        self.root.minsize(1100, 700)
        self.root.configure(bg="#eef3f8")
        self.records = []
        self.editing_id = None
        self._build_style()
        self._build_ui()
        self.load_data()
        self.refresh_table()

    def _build_style(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TFrame", background="#eef3f8")
        style.configure("TLabelframe", background="#ffffff", bordercolor="#d7e1ec")
        style.configure("TLabelframe.Label", background="#ffffff", foreground="#17324d",
                        font=("Segoe UI", 10, "bold"))
        style.configure("TLabel", background="#ffffff", foreground="#243b53",
                        font=("Segoe UI", 9))
        style.configure("Header.TLabel", background="#eef3f8", foreground="#12304a",
                        font=("Segoe UI", 19, "bold"))
        style.configure("Subheader.TLabel", background="#eef3f8", foreground="#61758a",
                        font=("Segoe UI", 9))
        style.configure("TButton", font=("Segoe UI", 9), padding=(10, 6))
        style.configure("Accent.TButton", background="#1769aa", foreground="white",
                        font=("Segoe UI", 9, "bold"))
        style.map("Accent.TButton", background=[("active", "#0f548b")])
        style.configure("Treeview", rowheight=28, font=("Segoe UI", 9),
                        background="white", fieldbackground="white")
        style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"),
                        background="#dce8f2", foreground="#17324d")
        style.map("Treeview", background=[("selected", "#b8d8f2")],
                  foreground=[("selected", "#102a43")])

    def _build_ui(self):
        header = ttk.Frame(self.root)
        header.pack(fill="x", padx=18, pady=(14, 8))
        ttk.Label(header, text="Медицинский центр", style="Header.TLabel").pack(anchor="w")
        ttk.Label(header, text="Регистрация пациентов и управление расписанием врачей",
                  style="Subheader.TLabel").pack(anchor="w", pady=(2, 0))

        content = ttk.Frame(self.root)
        content.pack(fill="both", expand=True, padx=14, pady=(4, 14))

        self.form_frame = ttk.LabelFrame(content, text="Данные пациента и запись", padding=12)
        self.form_frame.pack(side="left", fill="y", padx=(0, 10))
        self._build_form(self.form_frame)

        right = ttk.Frame(content)
        right.pack(side="left", fill="both", expand=True)
        self._build_search(right)
        self._build_table(right)
        self._build_actions(right)

    def _field(self, parent, label, variable, row, width=30):
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", pady=4)
        entry = ttk.Entry(parent, textvariable=variable, width=width)
        entry.grid(row=row, column=1, sticky="ew", pady=4)
        return entry

    def _build_form(self, parent):
        self.vars = {name: tk.StringVar() for name in [
            "last_name", "first_name", "middle_name", "iin", "birth_date",
            "phone", "email", "specialty", "doctor", "appointment_date",
            "appointment_time", "visit_type", "format"
        ]}
        self.vars["birth_date"].set("01.01.2000")
        self.vars["appointment_date"].set(date.today().strftime("%d.%m.%Y"))
        self.vars["visit_type"].set("Первичный")
        self.vars["format"].set("Очный")
        parent.columnconfigure(1, weight=1)

        row = 0
        ttk.Label(parent, text="Фамилия *").grid(row=row, column=0, sticky="w", pady=4)
        ttk.Entry(parent, textvariable=self.vars["last_name"], width=28).grid(row=row, column=1, sticky="ew", pady=4)
        row += 1
        ttk.Label(parent, text="Имя *").grid(row=row, column=0, sticky="w", pady=4)
        ttk.Entry(parent, textvariable=self.vars["first_name"]).grid(row=row, column=1, sticky="ew", pady=4)
        row += 1
        ttk.Label(parent, text="Отчество").grid(row=row, column=0, sticky="w", pady=4)
        ttk.Entry(parent, textvariable=self.vars["middle_name"]).grid(row=row, column=1, sticky="ew", pady=4)
        row += 1
        ttk.Label(parent, text="ИИН (12 цифр) *").grid(row=row, column=0, sticky="w", pady=4)
        ttk.Entry(parent, textvariable=self.vars["iin"]).grid(row=row, column=1, sticky="ew", pady=4)
        row += 1
        ttk.Label(parent, text="Дата рождения *").grid(row=row, column=0, sticky="w", pady=4)
        ttk.Entry(parent, textvariable=self.vars["birth_date"]).grid(row=row, column=1, sticky="ew", pady=4)
        row += 1
        ttk.Label(parent, text="Телефон *").grid(row=row, column=0, sticky="w", pady=4)
        ttk.Entry(parent, textvariable=self.vars["phone"]).grid(row=row, column=1, sticky="ew", pady=4)
        row += 1
        ttk.Label(parent, text="Электронная почта *").grid(row=row, column=0, sticky="w", pady=4)
        ttk.Entry(parent, textvariable=self.vars["email"]).grid(row=row, column=1, sticky="ew", pady=4)
        row += 1

        ttk.Separator(parent).grid(row=row, column=0, columnspan=2, sticky="ew", pady=9)
        row += 1
        ttk.Label(parent, text="Специальность *").grid(row=row, column=0, sticky="w", pady=4)
        self.specialty_combo = ttk.Combobox(parent, textvariable=self.vars["specialty"],
                                             values=list(DOCTORS), state="readonly", width=26)
        self.specialty_combo.grid(row=row, column=1, sticky="ew", pady=4)
        self.specialty_combo.bind("<<ComboboxSelected>>", self.update_doctors)
        row += 1
        ttk.Label(parent, text="Врач *").grid(row=row, column=0, sticky="w", pady=4)
        self.doctor_combo = ttk.Combobox(parent, textvariable=self.vars["doctor"],
                                          state="readonly", width=26)
        self.doctor_combo.grid(row=row, column=1, sticky="ew", pady=4)
        row += 1
        ttk.Label(parent, text="Дата приёма *").grid(row=row, column=0, sticky="w", pady=4)
        ttk.Entry(parent, textvariable=self.vars["appointment_date"]).grid(row=row, column=1, sticky="ew", pady=4)
        row += 1
        ttk.Label(parent, text="Время *").grid(row=row, column=0, sticky="w", pady=4)
        ttk.Combobox(parent, textvariable=self.vars["appointment_time"], values=TIMES,
                     state="readonly").grid(row=row, column=1, sticky="ew", pady=4)
        row += 1

        ttk.Label(parent, text="Тип приёма").grid(row=row, column=0, sticky="w", pady=4)
        visit_box = ttk.Frame(parent)
        visit_box.grid(row=row, column=1, sticky="w")
        ttk.Radiobutton(visit_box, text="Первичный", variable=self.vars["visit_type"],
                        value="Первичный").pack(side="left")
        ttk.Radiobutton(visit_box, text="Повторный", variable=self.vars["visit_type"],
                        value="Повторный").pack(side="left")
        row += 1
        ttk.Label(parent, text="Формат").grid(row=row, column=0, sticky="w", pady=4)
        format_box = ttk.Frame(parent)
        format_box.grid(row=row, column=1, sticky="w")
        ttk.Radiobutton(format_box, text="Очный", variable=self.vars["format"],
                        value="Очный").pack(side="left")
        ttk.Radiobutton(format_box, text="Онлайн", variable=self.vars["format"],
                        value="Онлайн").pack(side="left")
        row += 1

        ttk.Label(parent, text="Жалобы (до 300 символов)").grid(row=row, column=0, columnspan=2, sticky="w", pady=(8, 3))
        row += 1
        self.complaints = tk.Text(parent, height=4, width=35, wrap="word",
                                  font=("Segoe UI", 9), relief="solid", bd=1)
        self.complaints.grid(row=row, column=0, columnspan=2, sticky="ew")
        self.complaints.bind("<KeyPress>", self.limit_complaints)
        self.complaints.bind("<<Paste>>", self.limit_paste)
        row += 1
        self.char_label = ttk.Label(parent, text="0 / 300 символов")
        self.char_label.grid(row=row, column=0, columnspan=2, sticky="e", pady=(2, 6))
        self.complaints.bind("<KeyRelease>", self.update_char_count)

        row += 1
        self.save_button = ttk.Button(parent, text="Записаться на приём",
                                      style="Accent.TButton", command=self.add_or_update)
        self.save_button.grid(row=row, column=0, columnspan=2, sticky="ew", pady=(8, 4))
        row += 1
        ttk.Button(parent, text="Очистить форму", command=self.clear_form).grid(
            row=row, column=0, columnspan=2, sticky="ew")
        ttk.Label(parent, text="* — обязательные поля", foreground="#6b7c8f").grid(
            row=row + 1, column=0, columnspan=2, sticky="w", pady=(8, 0))

    def update_doctors(self, _event=None):
        specialty = self.vars["specialty"].get()
        doctors = DOCTORS.get(specialty, [])
        self.doctor_combo["values"] = doctors
        self.vars["doctor"].set(doctors[0] if doctors else "")

    def limit_complaints(self, event):
        if event.keysym in ("BackSpace", "Delete", "Left", "Right", "Up", "Down",
                            "Home", "End", "Tab") or event.state & 0x4:
            return
        current = self.complaints.get("1.0", "end-1c")
        if len(current) >= MAX_COMPLAINTS:
            return "break"

    def limit_paste(self, _event=None):
        self.root.after(10, self.trim_complaints)

    def trim_complaints(self):
        value = self.complaints.get("1.0", "end-1c")
        if len(value) > MAX_COMPLAINTS:
            self.complaints.delete("1.0", "end")
            self.complaints.insert("1.0", value[:MAX_COMPLAINTS])
        self.update_char_count()

    def update_char_count(self, _event=None):
        count = len(self.complaints.get("1.0", "end-1c"))
        self.char_label.config(text=f"{count} / {MAX_COMPLAINTS} символов")

    def _build_search(self, parent):
        box = ttk.LabelFrame(parent, text="Поиск и фильтрация", padding=9)
        box.pack(fill="x", pady=(0, 8))
        self.search_var = tk.StringVar()
        self.filter_doctor = tk.StringVar()
        self.filter_date = tk.StringVar()
        self.filter_status = tk.StringVar()
        ttk.Label(box, text="Ф. И. О. / ИИН:").grid(row=0, column=0, padx=4, pady=3)
        search_entry = ttk.Entry(box, textvariable=self.search_var, width=24)
        search_entry.grid(row=0, column=1, padx=4, pady=3)
        search_entry.bind("<KeyRelease>", lambda _e: self.refresh_table())
        ttk.Label(box, text="Врач:").grid(row=0, column=2, padx=4)
        doctors = sorted({d for group in DOCTORS.values() for d in group})
        ttk.Combobox(box, textvariable=self.filter_doctor, values=["Все"] + doctors,
                     state="readonly", width=24).grid(row=0, column=3, padx=4)
        ttk.Label(box, text="Дата:").grid(row=0, column=4, padx=4)
        date_entry = ttk.Entry(box, textvariable=self.filter_date, width=12)
        date_entry.grid(row=0, column=5, padx=4)
        date_entry.bind("<KeyRelease>", lambda _e: self.refresh_table())
        ttk.Label(box, text="Статус:").grid(row=0, column=6, padx=4)
        ttk.Combobox(box, textvariable=self.filter_status, values=["Все"] + STATUSES,
                     state="readonly", width=19).grid(row=0, column=7, padx=4)
        self.filter_doctor.set("Все")
        self.filter_status.set("Все")
        for widget in box.winfo_children():
            if isinstance(widget, ttk.Combobox):
                widget.bind("<<ComboboxSelected>>", lambda _e: self.refresh_table())
        ttk.Button(box, text="Показать все", command=self.reset_filters).grid(
            row=0, column=8, padx=5)

    def _build_table(self, parent):
        frame = ttk.LabelFrame(parent, text="Список записей", padding=8)
        frame.pack(fill="both", expand=True)
        columns = ("patient", "doctor", "specialty", "date", "time", "format", "status")
        self.tree = ttk.Treeview(frame, columns=columns, show="headings", selectmode="browse")
        headings = {
            "patient": "Пациент", "doctor": "Врач", "specialty": "Специальность",
            "date": "Дата", "time": "Время", "format": "Формат", "status": "Статус"
        }
        widths = {"patient": 170, "doctor": 190, "specialty": 125, "date": 90,
                  "time": 65, "format": 75, "status": 135}
        for col in columns:
            self.tree.heading(col, text=headings[col])
            self.tree.column(col, width=widths[col], minwidth=60, anchor="center")
        yscroll = ttk.Scrollbar(frame, orient="vertical", command=self.tree.yview)
        xscroll = ttk.Scrollbar(frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        yscroll.grid(row=0, column=1, sticky="ns")
        xscroll.grid(row=1, column=0, sticky="ew")
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        self.tree.bind("<<TreeviewSelect>>", self.on_select)
        self.tree.bind("<Double-1>", lambda _e: self.show_details())

        self.tree.tag_configure("planned", background="#eaf3ff")
        self.tree.tag_configure("accepted", background="#e7f6ec")
        self.tree.tag_configure("cancelled", background="#fdecec")
        self.tree.tag_configure("missed", background="#fff3d9")

    def _build_actions(self, parent):
        frame = ttk.Frame(parent)
        frame.pack(fill="x", pady=(8, 0))
        buttons = [
            ("Подробности", self.show_details),
            ("Изменить", self.edit_selected),
            ("Отменить запись", self.cancel_selected),
            ("Удалить", self.delete_selected),
            ("Изменить статус", self.change_status),
        ]
        for label, command in buttons:
            ttk.Button(frame, text=label, command=command).pack(side="left", padx=(0, 6))

    def collect_form(self):
        data = {key: var.get().strip() for key, var in self.vars.items()}
        data["complaints"] = self.complaints.get("1.0", "end-1c").strip()
        return data

    def validate_form(self, data):
        if not data["last_name"] or not data["first_name"]:
            return "Заполните фамилию и имя пациента."
        if not data["iin"].isdigit() or len(data["iin"]) != 12:
            return "ИИН должен состоять ровно из 12 цифр."
        try:
            birth = datetime.strptime(data["birth_date"], "%d.%m.%Y").date()
            if birth > date.today():
                return "Дата рождения не может быть в будущем."
            age = date.today().year - birth.year - ((date.today().month, date.today().day) < (birth.month, birth.day))
            if age > 120:
                return "Проверьте дату рождения: возраст не может превышать 120 лет."
        except ValueError:
            return "Дата рождения должна быть в формате ДД.ММ.ГГГГ."
        phone = data["phone"]
        if not phone or any(not (ch.isdigit() or ch in "+()- ") for ch in phone) or sum(ch.isdigit() for ch in phone) < 7:
            return "Введите корректный номер телефона."
        email = data["email"]
        if "@" not in email or "." not in email.split("@")[-1] or email.startswith("@"):
            return "Введите корректный адрес электронной почты."
        if not data["specialty"] or not data["doctor"]:
            return "Выберите специальность и врача."
        if data["doctor"] not in DOCTORS.get(data["specialty"], []):
            return "Выбранный врач не соответствует специальности."
        try:
            appointment = datetime.strptime(data["appointment_date"], "%d.%m.%Y").date()
            if appointment < date.today():
                return "Нельзя выбрать прошедшую дату приёма."
        except ValueError:
            return "Дата приёма должна быть в формате ДД.ММ.ГГГГ."
        if not data["appointment_time"]:
            return "Выберите время приёма."
        if data["appointment_time"] not in TIMES:
            return "Выберите время из предложенного списка."
        if len(data["complaints"]) > MAX_COMPLAINTS:
            return "Описание жалоб не должно превышать 300 символов."
        return None

    def has_conflict(self, data, ignored_id=None):
        for record in self.records:
            if record["id"] == ignored_id or record["status"] == "Отменён":
                continue
            if (record["doctor"] == data["doctor"]
                    and record["appointment_date"] == data["appointment_date"]
                    and record["appointment_time"] == data["appointment_time"]):
                return True
        return False

    def add_or_update(self):
        data = self.collect_form()
        error = self.validate_form(data)
        if error:
            messagebox.showerror("Ошибка заполнения", error)
            return
        if self.has_conflict(data, self.editing_id):
            messagebox.showwarning("Время занято",
                                   "Этот врач уже занят в выбранные дату и время. Выберите другое свободное время.")
            return

        if self.editing_id:
            for record in self.records:
                if record["id"] == self.editing_id:
                    record.update(data)
                    break
            messagebox.showinfo("Изменение записи", "Данные записи успешно изменены.")
        else:
            data["id"] = str(uuid.uuid4())
            data["status"] = "Запланирован"
            self.records.append(data)
            messagebox.showinfo("Успешно", "Пациент успешно записан на приём.")
        self.save_data()
        self.refresh_table()
        self.clear_form()

    def clear_form(self):
        self.editing_id = None
        for key, var in self.vars.items():
            var.set("")
        self.vars["birth_date"].set("01.01.2000")
        self.vars["appointment_date"].set(date.today().strftime("%d.%m.%Y"))
        self.vars["visit_type"].set("Первичный")
        self.vars["format"].set("Очный")
        self.doctor_combo["values"] = []
        self.complaints.delete("1.0", "end")
        self.update_char_count()
        self.save_button.config(text="Записаться на приём")

    def refresh_table(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        query = self.search_var.get().casefold() if hasattr(self, "search_var") else ""
        doctor_filter = self.filter_doctor.get() if hasattr(self, "filter_doctor") else "Все"
        date_filter = self.filter_date.get().strip() if hasattr(self, "filter_date") else ""
        status_filter = self.filter_status.get() if hasattr(self, "filter_status") else "Все"
        for record in self.records:
            patient = " ".join(x for x in [record["last_name"], record["first_name"], record["middle_name"]] if x)
            if query and query not in patient.casefold() and query not in record["iin"]:
                continue
            if doctor_filter not in ("", "Все") and record["doctor"] != doctor_filter:
                continue
            if date_filter and date_filter not in record["appointment_date"]:
                continue
            if status_filter not in ("", "Все") and record["status"] != status_filter:
                continue
            tag = {
                "Запланирован": "planned",
                "Пациент принят": "accepted",
                "Отменён": "cancelled",
                "Пациент не явился": "missed",
            }.get(record["status"], "")
            self.tree.insert("", "end", iid=record["id"], values=(
                patient, record["doctor"], record["specialty"],
                record["appointment_date"], record["appointment_time"],
                record["format"], record["status"]), tags=(tag,))

    def reset_filters(self):
        self.search_var.set("")
        self.filter_doctor.set("Все")
        self.filter_date.set("")
        self.filter_status.set("Все")
        self.refresh_table()

    def selected_record(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Не выбрана запись", "Сначала выберите запись в таблице.")
            return None
        record_id = selected[0]
        return next((r for r in self.records if r["id"] == record_id), None)

    def on_select(self, _event=None):
        # Подробные данные доступны двойным щелчком или кнопкой «Подробности».
        pass

    def show_details(self):
        record = self.selected_record()
        if not record:
            return
        window = tk.Toplevel(self.root)
        window.title("Подробности записи")
        window.geometry("470x590")
        window.transient(self.root)
        window.grab_set()
        body = ttk.Frame(window, padding=18)
        body.pack(fill="both", expand=True)
        ttk.Label(body, text="Информация о записи", font=("Segoe UI", 15, "bold")).pack(anchor="w", pady=(0, 12))
        labels = [
            ("Пациент", " ".join(x for x in [record["last_name"], record["first_name"], record["middle_name"]] if x)),
            ("ИИН", record["iin"]), ("Дата рождения", record["birth_date"]),
            ("Телефон", record["phone"]), ("Электронная почта", record["email"]),
            ("Специальность", record["specialty"]), ("Врач", record["doctor"]),
            ("Дата приёма", record["appointment_date"]), ("Время", record["appointment_time"]),
            ("Тип приёма", record["visit_type"]), ("Формат", record["format"]),
            ("Статус", record["status"]), ("Жалобы", record["complaints"] or "Не указаны")
        ]
        for label, value in labels:
            line = ttk.Frame(body)
            line.pack(fill="x", pady=3)
            ttk.Label(line, text=label + ":", width=19, font=("Segoe UI", 9, "bold")).pack(side="left", anchor="nw")
            ttk.Label(line, text=value, wraplength=275).pack(side="left", anchor="nw")
        ttk.Button(body, text="Закрыть", command=window.destroy).pack(anchor="e", pady=12)

    def edit_selected(self):
        record = self.selected_record()
        if not record:
            return
        self.editing_id = record["id"]
        for key in self.vars:
            self.vars[key].set(record.get(key, ""))
        self.doctor_combo["values"] = DOCTORS.get(record["specialty"], [])
        self.complaints.delete("1.0", "end")
        self.complaints.insert("1.0", record.get("complaints", ""))
        self.update_char_count()
        self.save_button.config(text="Сохранить изменения")
        self.root.focus_force()

    def cancel_selected(self):
        record = self.selected_record()
        if not record:
            return
        if record["status"] == "Отменён":
            messagebox.showinfo("Информация", "Эта запись уже отменена.")
            return
        record["status"] = "Отменён"
        self.save_data()
        self.refresh_table()
        messagebox.showinfo("Запись отменена", "Статус записи изменён на «Отменён».")

    def delete_selected(self):
        record = self.selected_record()
        if not record:
            return
        patient = " ".join(x for x in [record["last_name"], record["first_name"]] if x)
        if messagebox.askyesno("Подтверждение удаления",
                               f"Удалить запись пациента {patient}? Это действие нельзя отменить."):
            self.records = [r for r in self.records if r["id"] != record["id"]]
            self.save_data()
            self.refresh_table()
            messagebox.showinfo("Удаление", "Запись удалена.")

    def change_status(self):
        record = self.selected_record()
        if not record:
            return
        dialog = tk.Toplevel(self.root)
        dialog.title("Изменение статуса")
        dialog.geometry("330x150")
        dialog.transient(self.root)
        dialog.grab_set()
        ttk.Label(dialog, text="Выберите новый статус:").pack(padx=15, pady=(18, 8))
        status_var = tk.StringVar(value=record["status"])
        combo = ttk.Combobox(dialog, textvariable=status_var, values=STATUSES, state="readonly", width=27)
        combo.pack(padx=15, pady=4)

        def apply():
            record["status"] = status_var.get()
            self.save_data()
            self.refresh_table()
            dialog.destroy()
            messagebox.showinfo("Статус изменён", "Статус записи успешно обновлён.")

        ttk.Button(dialog, text="Сохранить статус", command=apply).pack(pady=12)

    def save_data(self):
        try:
            with open(CSV_FILE, "w", newline="", encoding="utf-8-sig") as file:
                writer = csv.DictWriter(file, fieldnames=CSV_FIELDS)
                writer.writeheader()
                for record in self.records:
                    writer.writerow({field: record.get(field, "") for field in CSV_FIELDS})
        except (OSError, csv.Error) as error:
            messagebox.showerror("Ошибка сохранения", f"Не удалось сохранить данные:\n{error}")

    def load_data(self):
        if not os.path.exists(CSV_FILE):
            return
        try:
            with open(CSV_FILE, "r", newline="", encoding="utf-8-sig") as file:
                reader = csv.DictReader(file)
                loaded = []
                for row in reader:
                    if all(field in row for field in CSV_FIELDS):
                        loaded.append({field: row.get(field, "") for field in CSV_FIELDS})
                self.records = loaded
        except (OSError, csv.Error, UnicodeError) as error:
            messagebox.showerror("Ошибка загрузки", f"Не удалось прочитать файл {CSV_FILE}:\n{error}")


def main():
    root = tk.Tk()
    AppointmentApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
